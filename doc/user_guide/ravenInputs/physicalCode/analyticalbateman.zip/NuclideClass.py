'''
Created on Jul 26, 2013

@author: andrea
'''

class NulclideClass():
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        self.nuclideName   = ''
        self.decayConstant = None
        self.decayTargetIsotope = ''
        self.crossSection  = []
        self.crossSectionTargetIsotope = ''
        