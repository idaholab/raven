'''
Created on Jul 26, 2013

@author: andrea
'''
from BatemanClass import *

if __name__ == '__main__':
    test = BatemanClass
    test.__init__(test)
    test.runDpl(test)
    test.printResults(test)